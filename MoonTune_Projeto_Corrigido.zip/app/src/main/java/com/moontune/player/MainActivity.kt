package com.moontune.player

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : AppCompatActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(android.graphics.Color.rgb(17, 16, 26))
        }

        val title = TextView(this).apply {
            text = "MoonTune"
            textSize = 30f
            setTextColor(android.graphics.Color.rgb(220, 210, 255))
        }
        val subtitle = TextView(this).apply {
            text = "Cole um link direto de áudio para testar a reprodução em segundo plano."
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, pad / 2, 0, pad)
        }
        val url = EditText(this).apply {
            hint = "https://exemplo.com/musica.mp3"
            setSingleLine(true)
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.LTGRAY)
        }
        val status = TextView(this).apply {
            text = "Conectando ao reprodutor..."
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val play = Button(this).apply { text = "Tocar link" }
        val pause = Button(this).apply { text = "Pausar" }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(url, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(play)
        layout.addView(pause)
        layout.addView(status)
        setContentView(layout)

        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                status.text = "Pronto. A reprodução pode continuar com outros apps abertos."
            } catch (e: Exception) {
                status.text = "Não foi possível iniciar o reprodutor."
            }
        }, ContextCompat.getMainExecutor(this))

        play.setOnClickListener {
            val text = url.text.toString().trim()
            if (!text.startsWith("https://")) {
                status.text = "Use um link HTTPS direto para um arquivo de áudio."
                return@setOnClickListener
            }
            val c = controller
            if (c == null) {
                status.text = "O reprodutor ainda está iniciando."
                return@setOnClickListener
            }
            c.setMediaItem(MediaItem.fromUri(Uri.parse(text)))
            c.prepare()
            c.play()
            status.text = "Tentando reproduzir o link..."
        }
        pause.setOnClickListener { controller?.pause() }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
