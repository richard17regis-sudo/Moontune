# MoonTune (projeto independente)

Este é um projeto novo e independente; não copia o código do ArchiveTune.

## O que já tem
- Serviço de reprodução em segundo plano usando Android Media3.
- Reprodução de um link HTTPS direto para áudio.
- Tentativa limitada de recuperação em erros de reprodução.
- Nome inicial MoonTune.
- Workflow do GitHub Actions para compilar um APK de teste na nuvem.

## Limitações importantes
- Este projeto NÃO é um APK pronto; precisa ser compilado.
- Não inclui catálogo de músicas nem busca de músicas.
- Só aceita links diretos para arquivos de áudio (por exemplo, MP3 hospedado num site), não páginas do YouTube ou links de serviços de streaming.
- A tentativa de recuperação é básica e não garante que todo erro possa ser corrigido.
- Ainda não foi compilado nem testado num aparelho real.

## Como compilar usando o celular (sem escrever código)
1. Crie uma conta no GitHub ou entre na sua conta.
2. Crie um repositório novo e envie os arquivos deste ZIP para ele mantendo as pastas.
3. Abra a aba **Actions** do repositório.
4. Se aparecer uma confirmação para habilitar Actions, habilite.
5. Escolha **Build MoonTune APK** e toque em **Run workflow**.
6. Quando terminar, abra a execução e baixe o artefato **MoonTune-debug-apk**.
7. Extraia o ZIP do artefato para encontrar `app-debug.apk`.

Não compartilhe senhas ou códigos de autenticação. A compilação pode falhar e exigir correções; este é um ponto de partida, não um aplicativo de catálogo completo.
